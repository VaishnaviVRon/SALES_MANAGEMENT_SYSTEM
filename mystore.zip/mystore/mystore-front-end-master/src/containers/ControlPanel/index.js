import React, { Component } from 'react';
import './style.css';

class ControlPanel extends Component {
    render() {
        return (
            <div>
                <h2>ControlPanel</h2>
            </div>
        );
    }
}

export default ControlPanel;